# Open conjecture — free to a good home

**Conjecture.** For unit-rate continuous-time SIS on the path P_n, the
infected-count observable k is cyclic on the reversal-invariant quotient
for every n — equivalently, the Krylov determinant D_n ≠ 0 for all n,
where D_n = det[1, k, Qk, …, Q^(d−2)k] in reversal-orbit coordinates
(d = number of reversal orbits of {0,1}^n; see verify_residue.py for the
exact construction, reconstructable from the anchors alone).

**Payoff if true.** Via a proved bridge (reversal commutes with the
generator; lumping blocks carry block-constant functions; Krylov
separation squeezes every block inside one orbit; orbits are a legal
lumping), the coarsest exact lumping of SIS on every path equals the
reversal orbits. The cycle version rides behind it.

**Evidence.**
- D_1 = 1, D_2 = −2, D_3 = −92, D_4 = −376552640 (exact; anchors).
- Exact nonvanishing through n = 8 (49- and 192-digit values at 5, 6).
- D_9, D_10, D_11 nonzero modulo p = 46000013 and p = 46000021,
  independently stranger-verified (see residue.md and verify_residue.py).

**What the taker inherits.**
- Two refuted proof routes, failure points named: the first-arrival
  triangular argument dies at n = 4 (four orbit classes at degree two,
  one leading Krylov vector); the raw endpoint-degree block-triangular
  n → n+2 recurrence is exactly refuted on P_3 (degree 0→1 couples with
  coefficient 1, degree 1→0 couples back with coefficient 2).
- The classical framing: D_n ≠ 0 iff (M_n, [1, k]) is Kalman-controllable;
  PBH gives the left-eigenvector criterion (Kalman 1963, Hautus 1969).
- The easy half is classical: automorphism orbits always lump
  (Simon–Taylor–Kiss 2011). The equality half is the open content;
  a literature audit found no primary source (NOVELTY_UNCHECKED → none found).

**Statuses.** Bridge: CONDITIONAL_THEOREM (proved). Finite cyclicity
n ≤ 8: COMPUTATIONAL_CERTIFICATE. D_9–D_11 ≠ 0: CERTIFIED_MOD_TWO_PRIMES,
stranger-verified. All-n: CANDIDATE_LEMMA — open.
