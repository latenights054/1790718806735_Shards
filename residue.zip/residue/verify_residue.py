#!/usr/bin/env python3
"""Stranger's verifier for the closing stanza of residue.md.

D_n := det[1, k, Qk, ..., Q^(d-2)k] for unit-rate SIS on the path P_n,
expressed in reversal-orbit coordinates (orbits ordered by minimal
representative). Anchors D1..D4 are checked exactly; D9, D10, D11 are
checked modulo two primes. A nonzero residue mod any prime forces a
nonzero integer, so a living residue proves nonvanishing; a zero
residue would have proven nothing. One-directional instrument, declared.

No estate code was used to write this. Reconstructed from four numbers.
"""
from fractions import Fraction

def orbits_and_transitions(n):
    N = 1 << n
    def rev(s):
        r = 0
        for v in range(n):
            if s >> v & 1:
                r |= 1 << (n - 1 - v)
        return r
    orbits = sorted({min(s, rev(s)) for s in range(N)})
    nbrs = [[] for _ in range(n)]
    for i in range(n - 1):
        nbrs[i].append(i + 1); nbrs[i + 1].append(i)
    trans = []
    for x in range(N):
        t = []
        for v in range(n):
            if x >> v & 1:
                t.append((x & ~(1 << v), 1))          # recovery, rate 1
            else:
                r = sum((x >> u) & 1 for u in nbrs[v])
                if r:
                    t.append((x | (1 << v), r))        # infection, rate = infected nbrs
        trans.append(t)
    return N, orbits, trans

def krylov_matrix(n, p=None):
    N, orbits, trans = orbits_and_transitions(n)
    d = len(orbits)
    def applyQ(f):
        g = [0] * N
        for x in range(N):
            acc = 0
            fx = f[x]
            for y, r in trans[x]:
                acc += r * (f[y] - fx)
            g[x] = acc % p if p else acc
        return g
    vecs = [[1] * N, [bin(x).count('1') for x in range(N)]]
    cur = vecs[1]
    for _ in range(d - 2):
        cur = applyQ(cur)
        vecs.append(cur)
    return [[vecs[j][orbits[i]] for j in range(d)] for i in range(d)], d

def det_exact(M, d):
    A = [[Fraction(v) for v in row] for row in M]
    det = Fraction(1)
    for c in range(d):
        piv = next((r for r in range(c, d) if A[r][c] != 0), None)
        if piv is None:
            return 0
        if piv != c:
            A[c], A[piv] = A[piv], A[c]; det = -det
        det *= A[c][c]
        for r in range(c + 1, d):
            if A[r][c] != 0:
                f = A[r][c] / A[c][c]
                for cc in range(c, d):
                    A[r][cc] -= f * A[c][cc]
    return int(det)

def det_mod(M, d, p):
    A = [[v % p for v in row] for row in M]
    det = 1
    for c in range(d):
        piv = next((r for r in range(c, d) if A[r][c]), None)
        if piv is None:
            return 0
        if piv != c:
            A[c], A[piv] = A[piv], A[c]; det = (-det) % p
        det = det * A[c][c] % p
        inv = pow(A[c][c], p - 2, p)
        Ac = A[c]
        for r in range(c + 1, d):
            if A[r][c]:
                f = A[r][c] * inv % p
                Ar = A[r]
                for cc in range(c, d):
                    Ar[cc] = (Ar[cc] - f * Ac[cc]) % p
    return det

ANCHORS = {1: 1, 2: -2, 3: -92, 4: -376552640}
CLAIMED = {
    46000013: {3: 45999921, 9: 26492851, 10: 31660956, 11: 39687161},
    46000021: {3: 45999929, 9: 37353938, 10: 28576809, 11: 1564789},
}

if __name__ == "__main__":
    ok = True
    for n, want in ANCHORS.items():
        M, d = krylov_matrix(n)
        got = det_exact(M, d)
        ok &= (got == want)
        print(f"D{n} = {got}  (expected {want})  {'OK' if got == want else 'FAIL'}")
    for p, rows in CLAIMED.items():
        print(f"p = {p}")
        for n, want in sorted(rows.items()):
            M, d = krylov_matrix(n, p)
            got = det_mod(M, d, p)
            ok &= (got == want)
            print(f"  D{n} ≡ {got}  (claimed {want})  {'OK' if got == want else 'FAIL'}")
    print("ALL CHECKS PASS — D9, D10, D11 are nonzero integers." if ok else "MISMATCH FOUND")
