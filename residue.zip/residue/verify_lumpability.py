#!/usr/bin/env python3
"""Cold replication of the essay's finite claims, rebuilt from prose alone.

Checks, for unit-rate SIS:
  1. coarsest exact (ordinary) lumpable partition == automorphism orbits,
     for paths P_1..P_12 and cycles C_3..C_12;
  2. the P_4 counterexample 0110 / 1001: identical coarse color c1=(2,2),
     different infected-endpoint counts (0 vs 2);
  3. the reversal-invariant dimension ladder 2,3,6,10,20,36,72,136 (P_1..P_8).
"""
def neighbors_path(n):
    nb = [[] for _ in range(n)]
    for i in range(n - 1):
        nb[i].append(i + 1); nb[i + 1].append(i)
    return nb

def neighbors_cycle(n):
    return [[(i + 1) % n, (i - 1) % n] for i in range(n)]

def transitions(n, nb):
    T = {}
    for s in range(1 << n):
        out = []
        for v in range(n):
            if s >> v & 1:
                out.append((s & ~(1 << v), 1.0))
            else:
                k = sum((s >> u) & 1 for u in nb[v])
                if k:
                    out.append((s | (1 << v), float(k)))
        T[s] = out
    return T

def coarsest_lumpable(n, T):
    block = {s: 0 for s in range(1 << n)}
    while True:
        sig = {}
        for s in range(1 << n):
            agg = {}
            for t, r in T[s]:
                agg[block[t]] = agg.get(block[t], 0.0) + r
            sig[s] = (block[s], tuple(sorted(agg.items())))
        lab, new = {}, {}
        for s in range(1 << n):
            if sig[s] not in lab:
                lab[sig[s]] = len(lab)
            new[s] = lab[sig[s]]
        if len(set(new.values())) == len(set(block.values())):
            return new
        block = new

def orbit_path(n):
    def rev(s):
        r = 0
        for v in range(n):
            if s >> v & 1:
                r |= 1 << (n - 1 - v)
        return r
    return {s: min(s, rev(s)) for s in range(1 << n)}

def orbit_cycle(n):
    def rot(s, k):
        return ((s << k) | (s >> (n - k))) & ((1 << n) - 1)
    def rev(s):
        r = 0
        for v in range(n):
            if s >> v & 1:
                r |= 1 << ((n - 1 - v) % n)
        return r
    block = {}
    for s in range(1 << n):
        reps = [rot(s, k) for k in range(n)]
        reps += [rev(x) for x in reps]
        block[s] = min(reps)
    return block

def same_partition(a, b):
    ga, gb = {}, {}
    for s in a:
        ga.setdefault(a[s], set()).add(s)
        gb.setdefault(b[s], set()).add(s)
    return set(map(frozenset, ga.values())) == set(map(frozenset, gb.values()))

if __name__ == "__main__":
    ok = True
    print("paths:")
    for n in range(1, 13):
        T = transitions(n, neighbors_path(n))
        L, O = coarsest_lumpable(n, T), orbit_path(n)
        eq = same_partition(L, O)
        ok &= eq
        print(f"  P_{n}: coarsest={len(set(L.values()))} orbits={len(set(O.values()))} equal={eq}")
    print("cycles:")
    for n in range(3, 13):
        T = transitions(n, neighbors_cycle(n))
        L, O = coarsest_lumpable(n, T), orbit_cycle(n)
        eq = same_partition(L, O)
        ok &= eq
        print(f"  C_{n}: coarsest={len(set(L.values()))} orbits={len(set(O.values()))} equal={eq}")
    nb = neighbors_path(4)
    def c1(s):
        inf = bin(s).count('1')
        bd = sum(1 for i in range(4) for j in nb[i] if j > i and ((s >> i & 1) != (s >> j & 1)))
        return (inf, bd)
    a, b = 0b0110, 0b1001
    ends = lambda s: (s & 1) + ((s >> 3) & 1)
    ok &= c1(a) == c1(b) == (2, 2) and ends(a) == 0 and ends(b) == 2
    print(f"counterexample: c1(0110)={c1(a)} c1(1001)={c1(b)} endpoints {ends(a)} vs {ends(b)}")
    ladder = [len(set(orbit_path(n).values())) for n in range(1, 9)]
    ok &= ladder == [2, 3, 6, 10, 20, 36, 72, 136]
    print("dimension ladder P_1..P_8:", ladder)
    print("ALL CHECKS PASS" if ok else "MISMATCH FOUND")
