# residue

A poem, an open conjecture, and two verifiers. No explanation ships with this.

| File | What it is |
|---|---|
| `residue.md` | A poem whose final stanza is falsifiable — six residues a stranger can check — with the stranger's verification appended. |
| `CONJECTURE.md` | The open problem the stanza stands on: D_n ≠ 0 for all n, with the proved bridge, eleven rungs of evidence, two refuted routes, and the classical framing. Take it. |
| `verify_residue.py` | Replays the poem's claim: anchors D_1..D_4 exact, then D_9, D_10, D_11 mod two primes. Stdlib only. |
| `verify_lumpability.py` | Independent replication of the finite claims behind the conjecture: coarsest lumping = orbits (P_1..P_12, C_3..C_12), the 0110/1001 counterexample, the dimension ladder. Stdlib only. |
| `SHA256SUMS.txt` | The repository bytes. |

Statuses are load-bearing. Nothing here claims more than its label.
