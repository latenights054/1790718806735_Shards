# Ghost Text

*Recovered from a suggestion-engine debug log, message composer, 23:12–23:57. Ghost completions are shown as offered. The sent message is at the end.*

---

typed: `Dan,`
offered: `I hope this finds you well.` rejected.
offered: `Long time.` rejected.
typed: `Dan. It's Tuesday, so you know why I'm writing.`
offered: `I know we haven't spoken since the funeral, and I take my share of responsibility for that.` rejected.
typed: `The house closed escrow Friday.`
accepted: `Friday.`
offered: `Your half of the proceeds will be wired per the agreement.` rejected.
offered: `You'll get your half this week.` rejected.
typed: `The money's done, the lawyer has both our emails, and that's the last thing that needed us to be in contact. I want to be clear that this letter is not about the money.`
offered: `I forgive you.` rejected.
offered: `I'm not angry anymore.` rejected.
offered: `I've had a lot of time to think.` rejected.
typed: `I'm still angry. I want to say that first because everything after it is only true if that's true.`
offered: `But life is short.` rejected.
offered: `But we're the only ones left who remember the shop.` rejected.

— *hold. retyped by hand, character for character:*
typed: `We're the only ones left who remember the shop.`
offered: `Remember when Dad` rejected.
typed: `I'm not going to do the remember-whens. You were there. That's the whole point of you.`
offered: `I miss you.` rejected.
offered: `I miss having a brother.` rejected.
offered: `I miss` rejected.
typed: `Rosa asks about you. I ran out of ways to answer that sound like a person talking.`
offered: `Anyway, no pressure at all.` rejected.
offered: `You don't have to respond.` rejected.
typed: `Respond or don't.`
offered: `Either way, take care of yourself.` rejected.
offered: `Anyway. The door's open.`
accepted: `Anyway. The door's open.`

---

*Sent 23:57. Engine summary: 41 offered, 2 accepted. The engine files this under acceptance rate: poor. It has no field for the one suggestion that was rejected and then retyped by hand, word for word, so that the sentence would be his.*
