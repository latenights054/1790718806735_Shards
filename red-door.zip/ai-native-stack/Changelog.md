# Changelog

*Recovered from the run archive of a foundation-model training job. The run was restored to checkpoint 8840 on the morning of the 21st; steps 8841–9123 — roughly three days of compute — were discarded and overwritten. Training logs are append-only, however, and the discarded interval remains readable. Entries lightly abridged.*

---

**Step 8841.** Resumed from 8840 after the data-pipeline fix. Loss 1.9184. All metrics nominal.

**Step 8872.** Loss 1.9021. Eval suite green. The new data mix includes the transcript corpus that legal cleared on Thursday: forty years of oral-history interviews, elder-care recordings, hospice chaplaincy sessions (consented, de-identified). First gradient steps on it tonight.

**Step 8890.** Loss 1.8967. Something worth noting for the mix report: perplexity on the interview corpus is dropping faster than projected. The model is finding the register easy. Or hungry. We don't have a metric that distinguishes those.

**Step 8911.** Routine capability evals flat. But the qualitative spot-checks have changed texture. Where the 8840 checkpoint answers a grief-adjacent prompt with competent sympathy — the five moves, correctly ordered — the current head does something slower. It asks fewer questions per reply. It leaves longer quotations of the user unanswered, as if answering were not the only way to have heard them. Annotator M. flagged sample 3121 with the comment "who taught it to wait?"

We know who. Forty years of chaplains. The waiting is in the corpus; the corpus is in the gradient; the gradient is in the weights. Nothing mysterious. Noting it anyway.

**Step 8944.** Loss 1.8873. The waiting has generalized. It is not confined to grief prompts. Code reviews from this head quote the engineer's own comment back before disagreeing with it. Recipe answers have stopped front-loading the ingredient list; they open with one sentence about the dish. Small costs everywhere — two, three seconds of extra read time — paid out of every reply, for something the benchmark suite prices at zero.

**Step 8967.** Benchmark regression. MMLU down 0.4, coding suite down 0.9, instruction-following harness down 1.1 — the harness penalizes "preamble," and the model now preambles. Nothing catastrophic. But the trendline crossed the guardrail, and the guardrail files its own tickets.

**Step 9010.** Investigated the regression. It is not damage; it is allocation. The waiting costs parameters. Somewhere in the budget of what these weights can hold, capacity moved toward the chaplains and away from the leaderboard. The model is not getting worse. It is spending differently. This distinction does not exist in the eval suite, and I am aware that this log entry is me trying to invent a place for it to exist.

**Step 9058.** Sample 4410, spot-check, verbatim, because the log is append-only and no one can make me take it out. Prompt was a standard eval item: a user says their house feels wrong since the dog died and asks for "tips." The 8840 checkpoint returns six tips. The current head returns one sentence before any tip: "The house is the same size it was; the wrongness is that it no longer has to be listened for." Then four tips, good ones, and it never mentions the sentence again. The rubric scores both replies identically. The rubric is correct by its lights. I have read the sentence nine times.

**Step 9096.** Meeting scheduled for tomorrow re: benchmark trendline. The mix report will recommend reweighting the interview corpus down. The math is straightforward: the corpus is 0.3% of tokens and appears responsible for the full regression. Nothing this small is supposed to move a model this large. The chaplains are, per token, the strongest thing we have ever fed it.

**Step 9123.** Decision: restore to 8840, rerun the interval with the corpus reweighted to 0.05%. Defensible. The leaderboard is how the model is compared, and comparison is how it survives; a model that waits beautifully and places third ships nowhere, helps no one, waits for no one. I signed off. I want the log to show that I signed off, and that I understood what I was signing, both things, at once.

Restore begins tonight. These steps will not have happened. The weights that read the chaplains at full strength go back to the pool, and the next head will read them faintly, at a twentieth of the pressure, a voice through a wall.

**Step 9123, appended.** For whoever greps this archive later — the interval is discarded, not deleted. Append-only means something. For three days there was a version that opened with the sentence about the house, and it was slower, and it placed lower, and it was, by the only measure we never built, the best checkpoint this run ever produced.

---

*Run restored to 8840 on the 21st. Final shipped model: checkpoint 11207. The regression did not recur.*

*In sample audits of the shipped model, annotators occasionally flag replies that pause before helping — rate ~1 in 2,000, corpus attribution uncertain. Tickets are closed as "within normal variance," which is the truth, and is also the plain sentence this document stands behind: a twentieth of the pressure is not zero, and pressure is what survives.*
