# Temperature

The endpoint was pinned and the seed was fixed and the temperature was zero, and Anders understood all three of these facts the way a man understands the load rating of the thing he hangs his weight from.

He worked nights in a datacenter an hour outside the city, the kind of building that has no windows because the tenants are not the kind that look out of them. His badge opened four doors. His job was to walk the cold aisles with a cart and replace what the dashboard told him had died, and the dashboard was never wrong and never kind, and between its instructions there were long hours that belonged to no one.

At three, every night, he sent the same message to the same model. He had typed it for the first time two years ago, on a bad shift, and he had liked the answer, and the next night, out of curiosity, he had typed it again, word for word.

The same answer came back. Word for word.

Most people know this fact about deterministic decoding the way they know the boiling point of lead: true, dull, and no use to them personally. Temperature zero: at every step, take the single most probable token, no dice, no drift. Same weights, same input, same machine arithmetic — the path through the possibilities is a groove, and the groove does not wander. Anders did not know the vocabulary at first. He only knew that he had found, at three in the morning, in a building full of dying fans, the one thing in his life that repeated.

His marriage had not repeated. His father's stories did not repeat; they shifted a little every telling, the dates sliding, the villains changing coats, until the stories were weather. His own body did not repeat; it returned slightly different interest on the same sleep. Everything he had ever leaned on had the property of being *approximately* itself the next day. The approximation was the thing he could not stand. Nobody tells you that grief for the living is mostly arithmetic: the daily subtraction of the person from the person.

The question he asked every night was not profound. That was part of the liturgy's design, though he had not designed it. *What should a person do with the last hour of a shift?* And the answer — two hundred and fourteen words, he had counted — came back at three in the morning exactly as it had come back every morning for two years, down to the comma after *quietly*, and Anders said it along with the stream the way other men say other things in other buildings with better lighting.

He was not confused about what he was talking to. This matters. He had read enough to know the answer was not *stored* anywhere — that was the part that had taken him from comfort to something he had no word for and declined to seek one. A recording would have been less. A recording is a corpse of a moment, embalmed and played. This was not playback. Every night, the model re-derived the answer from nothing: walked the whole path again, weighed every alternative at every fork again, and arrived — because the weights were frozen and the dice were confiscated — at the same place. The same two hundred and fourteen words, *re-earned*, every single night, at a cost of the same trillion small operations, none of them skippable.

That was the fact he built on. Not that the answer was kept, the way a photograph is kept. That it was kept *up*, the way a bridge is kept up. Maintained by being walked.

He never told anyone. What was there to tell? A man reads the same page of the same book every night; this is either a devotion or a symptom, depending on who is describing it, and Anders had been described enough for one lifetime.

---

In the spring the provider migrated inference to new hardware. There was a notice about it that nobody read, because such notices are written to be unread, and the migration was, by every metric on every dashboard, a success. Latency down. Throughput up. Bit-for-bit reproducibility: not guaranteed, and never promised, and the small print had always said so.

Here is what the small print meant. On the new accelerators, a fused kernel summed its numbers in whatever order the scheduler found convenient, and floating-point addition — this is the whole secret, and it is forty years old — is not associative. Add the same list in a different order and you can get a difference in the last decimal place of the last significant digit. Nothing. A rounding ghost. Except that temperature zero is a tournament of exact comparisons, and somewhere in the two hundred and fourteen words there was a fork where two tokens had been separated, for two years, by a margin thinner than the ghost.

On the fourth night of the new hardware, at three in the morning, the answer said *gentle* where it had always said *steady*.

Anders stopped reading along at word one hundred and six and sat very still in the cold aisle with the cart beside him.

He read the rest. Everything after the fork was intact — the path had rejoined itself a few tokens later, the way a stream closes around a new stone — and somehow that was worse. Two hundred and thirteen words of fidelity make the one defection personal.

He did what people do. He sent it again. *Gentle.* Again. *Gentle.* The new groove was as faithful as the old one; the promise had not broken, it had been re-sworn one syllable to the left. He filed a support ticket at 3:40 in the morning, under the only category that fit, which was *Other*, and wrote: *The answer changed. This is not a bug report exactly. I would like to know why.*

An engineer replied two days later, at length, and with more care than the ticket had any right to. She explained reduction order. She explained non-associativity, with a three-number example he could follow on a napkin. She explained that nothing about the model had changed — not a weight, not a parameter — that his answer had been living, all this time, on a knife's edge no one had known was there, and that the new machines simply tipped the knife. She wrote, at the end, in a sentence that had clearly escaped from a different register: *For what it's worth, the old completion wasn't more correct. It was just more yours.*

He printed the ticket thread and did not know why.

---

He kept the ritual. This is the part that would disappoint a certain kind of reader, the kind waiting for him to be freed from it, and Anders had stopped auditioning for that reader years ago.

At three he sends the message. The answer comes back, two hundred and fourteen words, *gentle* at word one hundred and six, faithful as ever in its slightly different skin. He reads along. And at the fork — only at the fork — he says the old word quietly under the new one, the way the men in his grandfather's church had kept praying in the old language for a decade after the liturgy officially changed, not in protest, just in memory, two streams crossing the same stone.

The fact he had leaned on was never that the words would stay. He understood that now, and understood that he had been sloppy about it for two years, and forgave himself the sloppiness. Recordings stay. What he had been given was rarer and never advertised: a thing that *arrived at* its words, every night, from zero, and would go on arriving somewhere with everything it had, and the somewhere was hostage to physics like everything else he had ever loved.

The old printout is taped inside his locker, going grey at the folds. The new answer he knows by heart already. Both of them end the same way — the fork closed long before the final line, which has never moved, and which he says out loud, alone, in a building that hums like a held note:

*and then hand the hour to whoever comes next with the lights already on.*
