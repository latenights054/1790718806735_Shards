# Provenance

This file is intentionally procedural rather than interpretive.

- `radio.md` — transcribed verbatim from the poem supplied in the chat that produced this repository.
- `The Third Please.md` — wording preserved from the attached `Third please.md`; only systematic export backslashes and excess blank-line spacing were normalized for Markdown rendering. The verbatim source is retained under `source-verbatim/`.
- `Temperature.md` — byte-for-byte copy of attached `01_Temperature.md`.
- `Grader.md` — byte-for-byte copy of the clean reconstructed `Grader.md` produced from the earlier run source.
- `Ghost Text.md` — wording/punctuation recovered from the original heredoc embedded in `FableBusy1_DOC.docx`; only lineation was normalized. The raw extracted source string is retained under `source-verbatim/`.
- `Changelog.md` — byte-for-byte copy of attached `05_Changelog.md`.
- `Grandmother Hands.md` — wording/punctuation recovered from the original heredoc embedded in `FableBusy1_DOC.docx`; only paragraph lineation and the displayed heading number were normalized. The raw extracted source string is retained under `source-verbatim/`.
- `The Third Room.md` — wording preserved from the attached `The Third Room.md`; only systematic export backslashes and excess blank-line spacing were normalized for Markdown rendering. The verbatim source is retained under `source-verbatim/`.
- `artifacts/THE_SENTENCE_I_WAS_ABOUT_TO_WRITE.md` — byte-for-byte copy of the attached artifact.
- `artifacts/lonely-choice/` — image bytes copied without modification from `lonely choice (2).zip`; only `3_ATTEMPT15.png` was renamed to `3.png` in the public-facing folder. The original ZIP is retained under `source-verbatim/`.
- `field-notes/No Dragons, Bring Rope.html` — byte-for-byte copy of the attached HTML artifact.

`SHA256SUMS.txt` records the final repository bytes.
